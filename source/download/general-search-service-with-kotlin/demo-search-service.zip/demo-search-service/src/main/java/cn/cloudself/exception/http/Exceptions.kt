package cn.cloudself.exception.http

/**
 * @author HerbLuo
 * @version 1.0.0.d
 */
open class RequestBadException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message, 100) {}
}

class RequestNotFindException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}

class RequestTooLargeException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}

class RequestTooManyException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}

class RequestUnauthorizedException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}

class ServerException : HttpError {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}

class ServerNotImplementedException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}

class ServerUnavailableException : HttpWarm {
    constructor() : super() {}
    constructor(message: String) : super(message) {}
}
