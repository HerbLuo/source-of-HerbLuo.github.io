package cn.cloudself.controller;

import cn.cloudself.service.ISearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author HerbLuo
 * @version 1.0.0.d
 * <p>
 * change logs:
 * 2017/12/27 HerbLuo 首次创建
 */
@RestController
@RequestMapping("/search-service")
public class SearchController {

    private final ISearchService searchService;

    @Autowired
    public SearchController(ISearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping("/{entityName}/{property}/{searchText}/")
    public Iterable<?> search(@PathVariable String entityName,
                              @PathVariable String property,
                              @PathVariable String searchText,
                              @RequestParam Integer page,
                              @RequestParam Integer size) throws Exception {
        return searchService.search(
                entityName,
                property,
                searchText,
                PageRequest.of(page, size)
        );
    }
}
