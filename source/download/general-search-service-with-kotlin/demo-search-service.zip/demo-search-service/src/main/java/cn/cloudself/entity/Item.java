package cn.cloudself.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * @author HerbLuo
 * @version 1.0.0.d
 * <p>
 * change logs:
 * 2017/12/26 HerbLuo 首次创建
 */
@Entity
public class Item {
    private int id;
    private byte enabled;
    private Timestamp modifyTime;
    private String version;
    private String name;
    private Double price;
    private String description;
    private String picLinksJson;
    private Integer detailDivId;
    private Integer discount;
    private Shop shop;

    @Id
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "enabled")
    public byte getEnabled() {
        return enabled;
    }

    public void setEnabled(byte enabled) {
        this.enabled = enabled;
    }

    @Basic
    @Column(name = "modify_time")
    public Timestamp getModifyTime() {
        return modifyTime;
    }

    public void setModifyTime(Timestamp modifyTime) {
        this.modifyTime = modifyTime;
    }

    @Basic
    @Column(name = "version")
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "price")
    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    @Basic
    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "pic_links_json")
    public String getPicLinksJson() {
        return picLinksJson;
    }

    public void setPicLinksJson(String picLinksJson) {
        this.picLinksJson = picLinksJson;
    }

    @Basic
    @Column(name = "detail_div_id")
    public Integer getDetailDivId() {
        return detailDivId;
    }

    public void setDetailDivId(Integer detailDivId) {
        this.detailDivId = detailDivId;
    }

    @Basic
    @Column(name = "discount")
    public Integer getDiscount() {
        return discount;
    }

    public void setDiscount(Integer discount) {
        this.discount = discount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Item item = (Item) o;
        return id == item.id &&
                enabled == item.enabled &&
                Objects.equals(modifyTime, item.modifyTime) &&
                Objects.equals(version, item.version) &&
                Objects.equals(name, item.name) &&
                Objects.equals(price, item.price) &&
                Objects.equals(description, item.description) &&
                Objects.equals(picLinksJson, item.picLinksJson) &&
                Objects.equals(detailDivId, item.detailDivId) &&
                Objects.equals(discount, item.discount);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, enabled, modifyTime, version, name, price, description, picLinksJson, detailDivId, discount);
    }

    @ManyToOne
    @JoinColumn(name = "shop_id", referencedColumnName = "id", nullable = false)
    public Shop getShop() {
        return shop;
    }

    public void setShop(Shop shop) {
        this.shop = shop;
    }
}
