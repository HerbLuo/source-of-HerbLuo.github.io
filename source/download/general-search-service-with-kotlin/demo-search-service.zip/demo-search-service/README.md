1. 数据库文件位于sql目录下，数据库名可使用 search_service_demo
2. 修改src/main/resources/db.properties 下的数据库用户名和密码
3. 配置好Tomcat Server后运行
4. 打开浏览器，测试以下 url中任意几个
```
http://localhost:8080/search-service/Item/price/71.9/?size=5&page=0
http://localhost:8080/search-service/Item/price/[~50 ~ 100]/?size=5&page=0
http://localhost:8080/search-service/Item/shop.name/%E5%93%87%E5%93%88%E5%93%88/?size=5&page=0
http://localhost:8080/search-service/Item/modifyTime/[~1495756800000 ~ 1495843200000]/?size=5&page=0
```