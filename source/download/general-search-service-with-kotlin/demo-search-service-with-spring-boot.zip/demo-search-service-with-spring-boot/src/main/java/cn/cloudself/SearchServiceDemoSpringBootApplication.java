package cn.cloudself;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchServiceDemoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchServiceDemoSpringBootApplication.class, args);
	}
}
