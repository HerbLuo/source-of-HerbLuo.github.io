package cn.cloudself.service

import org.springframework.data.domain.Pageable

/**
 * @author HerbLuo
 * @version 1.0.0.d
 *
 *
 * change logs:
 * 2017/11/21 HerbLuo 首次创建
 */
interface ISearchService {

    @Throws(Exception::class)
    fun search(entityName: String, properties: String, searchText: String,
               pageable: Pageable): Iterable<*>

    @Throws(Exception::class)
    fun <T>search(entityName: String, properties: String, searchText: String,
                  pageable: Pageable, clazz: Class<T>): Iterable<T>

}
