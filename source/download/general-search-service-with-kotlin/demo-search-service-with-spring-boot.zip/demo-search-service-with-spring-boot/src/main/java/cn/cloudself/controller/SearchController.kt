package cn.cloudself.controller

import cn.cloudself.service.ISearchService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Pageable
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

/**
 * @author HerbLuo
 * @version 1.0.0.d
 *
 * change logs:
 * 2017/12/25 HerbLuo 首次创建
 */
@RestController
@RequestMapping("/search-service")
class SearchController @Autowired constructor(
        private val searchService: ISearchService
) {

    /**
     * 搜索服务
     * 最后一个斜杠不宜去掉，否则无法搜索浮点数
     */
    @Throws(Exception::class)
    @GetMapping("/{entityName}/{property}/{searchText}/")
    fun search(@PathVariable entityName: String,
               @PathVariable property: String,
               @PathVariable searchText: String,
               pageable: Pageable): Iterable<*> =
            searchService.search(
                    entityName,
                    property,
                    searchText,
                    pageable
            )

}