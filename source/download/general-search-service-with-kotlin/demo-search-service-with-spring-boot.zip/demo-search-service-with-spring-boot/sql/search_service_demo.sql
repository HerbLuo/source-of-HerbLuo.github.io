/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : search_service_demo

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-12-27 00:54:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for item
-- ----------------------------
DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `version` char(6) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `price` double unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `pic_links_json` varchar(500) DEFAULT NULL,
  `shop_id` int(11) unsigned NOT NULL,
  `detail_div_id` int(11) unsigned DEFAULT NULL,
  `discount` int(11) unsigned DEFAULT NULL COMMENT '降低的价格，非百分比',
  PRIMARY KEY (`id`),
  KEY `name` (`name`) USING BTREE,
  KEY `price` (`price`) USING BTREE,
  KEY `FKbsswvl04podecnq8d6mbqnblu` (`detail_div_id`) USING BTREE,
  KEY `FKso5mqbn1h85iop14ahckkwahh` (`shop_id`) USING BTREE,
  CONSTRAINT `item_ibfk_1` FOREIGN KEY (`shop_id`) REFERENCES `shop` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of item
-- ----------------------------
INSERT INTO `item` VALUES ('1', '1', '2017-03-08 18:52:32', '1', '咱的牛奶不好吃，贵在量多', '100', '1斤新鲜牛奶只要100块', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/9d2db4e02a6777064f4b38722ac23a87.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/39b27aa5ad7a59aa59771d9cb3f20c8e.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/412d6e8ccfb6a187fd919f77b1e3612f.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/dbc80ba3fe16625cae4060cf79918030.jpg\"]', '1', '1', null);
INSERT INTO `item` VALUES ('2', '1', '2017-03-08 18:49:31', '1', '批发牛奶', '50', '好评返现100元', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/b2c203b8e2e1678f766ce2798c18e623.jpg\"]', '1', null, null);
INSERT INTO `item` VALUES ('3', '1', '2017-03-08 18:52:32', '1', '旺仔小馒头，非牛奶', '99.9', '现在不少商家拿牛奶冒充馒头，大家注意啦', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/wangzaixiaomantou.jpg\"]', '1', null, null);
INSERT INTO `item` VALUES ('4', '1', '2017-03-08 18:52:32', '1', '批发牛奶', '25', '新鲜的牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '2', null, null);
INSERT INTO `item` VALUES ('5', '1', '2017-03-08 18:52:32', '2', '伊利牛奶', '23', '好奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '4', null, null);
INSERT INTO `item` VALUES ('6', '1', '2017-03-08 18:52:32', '2', '牛奶', '45', '纯牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '3', null, null);
INSERT INTO `item` VALUES ('7', '1', '2017-03-08 18:52:32', 'a', '牛奶整箱', '57', '24盒', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '2', null, null);
INSERT INTO `item` VALUES ('8', '1', '2017-03-08 18:52:32', 'a', '牛奶', '78', '进口牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '3', null, null);
INSERT INTO `item` VALUES ('9', '1', '2017-03-08 18:52:32', 'd', '羊奶，非牛奶', '98', '非常新鲜的羊奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '4', null, null);
INSERT INTO `item` VALUES ('10', '1', '2017-03-08 18:52:32', 'a', '饼干', '23', '饼干，搭配牛奶更好吃', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '1', null, null);
INSERT INTO `item` VALUES ('11', '1', '2017-03-08 18:52:32', '1', '羊肉串', '39', '辸的羊肉串', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '3', null, null);
INSERT INTO `item` VALUES ('12', '1', '2017-03-08 18:52:32', 'w', '大包装牛奶', '200', '300ml大包装牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '2', null, null);
INSERT INTO `item` VALUES ('13', '1', '2017-03-08 18:52:32', 's', '伊利谷粒多谷物牛奶饮品谷物牛奶12*250ml', '44', '伊利谷粒多', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '3', null, null);
INSERT INTO `item` VALUES ('14', '1', '2017-03-08 18:52:32', 'e', '伊利高钙低脂牛奶 纯牛奶250ml*24无菌装', '71.9', '伊利高钙低脂牛奶 纯牛奶250ml*24无菌装', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/gaogainai.jpg\"]', '2', null, null);
INSERT INTO `item` VALUES ('15', '1', '2017-03-08 18:52:32', 'wq', '新希望香蕉牛奶200ml*12盒*2箱 韩国风味早餐奶 整箱果味牛奶', '89', '双十1 爆售 30000箱 生牛乳加 稀奶油调制', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '4', null, null);
INSERT INTO `item` VALUES ('16', '1', '2017-03-08 18:52:32', 'sd', '送瓜子 李子园甜牛奶含乳饮料225ml*24整箱学生饮品江浙沪皖包邮', '40', '送瓜子 李子园甜牛奶含乳饮料225ml*24整箱学生饮品江浙沪皖包邮', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/liziyuan.jpg\"]', '4', null, null);
INSERT INTO `item` VALUES ('17', '1', '2017-03-08 18:52:32', 'q', '甜牛奶', '56', '很甜很甜的牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '1', null, null);
INSERT INTO `item` VALUES ('18', '1', '2017-03-08 18:52:32', 'w', '酸牛奶', '55', '很酸很酸的牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/suanniunai.jpg\"]', '1', null, null);
INSERT INTO `item` VALUES ('19', '1', '2017-03-08 18:52:32', 's', '牛奶面包', '3', '新鲜的面包，牛奶味', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '2', null, null);
INSERT INTO `item` VALUES ('20', '1', '2017-03-08 18:52:32', 'd', '鸡蛋面包', '9', '鸡蛋面包', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/38c0266046c2433a6d2558a101efb8ac.jpg\"]', '3', null, null);
INSERT INTO `item` VALUES ('21', '1', '2017-03-08 18:52:32', '1.0', '德芙巧克力，送牛奶', '56', '买三份送一瓶250ml猛牛牛奶', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/qiaokeli.jpg\"]', '1', null, null);
INSERT INTO `item` VALUES ('22', '1', '2017-05-26 10:53:55', '2.0', '光明 利乐砖 纯牛奶促销250ml *24盒/箱 10月产', '61.8', '光明牛奶就是好喝', '[\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/guangmingniunai1.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/guangmingniunai2.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/guangmingniunai3.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/guangmingniunai4.jpg\",\"//closx-shop.oss-cn-qingdao.aliyuncs.com/images/19a4fefb578960a123aa813b28394cb1828162b8.jpg\"]', '1', null, null);

-- ----------------------------
-- Table structure for shop
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(16) DEFAULT NULL,
  `seller_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES ('1', '1', '哇哈哈牛奶旗舰店', '4');
INSERT INTO `shop` VALUES ('2', '1', '猛牛牛奶', '2');
INSERT INTO `shop` VALUES ('3', '1', '牛奶批发', '3');
INSERT INTO `shop` VALUES ('4', '1', '进口牛奶批发中心', '2');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(16) NOT NULL DEFAULT '',
  `username` varchar(16) NOT NULL,
  `password` char(64) NOT NULL,
  `group` tinyint(3) unsigned NOT NULL,
  `enable` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'Ghosted', 'ghosted', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '1', '1');
INSERT INTO `user` VALUES ('2', 'Test', 'test', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '6', '0');
INSERT INTO `user` VALUES ('3', 'Admin', 'admin', '91d5a6e14b65d42c4ab6b415673b60dfd457db4b70ebb8622c9745326a6714b3', '2', '1');
INSERT INTO `user` VALUES ('4', 'User', 'user', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '6', '1');
INSERT INTO `user` VALUES ('5', 'TEST USER', 'UDEV1', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('6', 'TEST USER', 'UDEV2', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '1');
INSERT INTO `user` VALUES ('7', 'TEST USER', 'UDEV4', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('8', 'TEST USER', 'UDEV5', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('11', 'TEST USER', 'UDEV6', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '1');
INSERT INTO `user` VALUES ('12', 'TEST USER', 'UDEV7', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('13', 'TEST USER', 'UDEV7\r\n', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('14', 'TEST USER', 'UDEV8', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('15', 'TEST USER', 'UDEV9', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '1');
INSERT INTO `user` VALUES ('16', 'TEST USER', 'UDEV10', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('17', 'TEST USER', 'UDEV11', '49dc52e6bf2abe5ef6e2bb5b0f1ee2d765b922ae6cc8b95d39dc06c21c848f8c', '9', '0');
INSERT INTO `user` VALUES ('18', 'TEST USER', 't1', '', '9', '1');
INSERT INTO `user` VALUES ('19', 'TEST USER', 't14', '', '9', '0');
INSERT INTO `user` VALUES ('21', 'TEST USER2', 't15', '', '9', '0');
INSERT INTO `user` VALUES ('22', 'TEST USER2', 't157', '', '9', '0');
INSERT INTO `user` VALUES ('23', 'TEST USER', 't1578', '', '9', '0');
INSERT INTO `user` VALUES ('24', 'TEST USER', 't1568', '', '9', '0');
INSERT INTO `user` VALUES ('29', 'TEST USER', 't19', '', '9', '0');
INSERT INTO `user` VALUES ('30', 'TEST USER', 't1d9', '', '9', '0');
INSERT INTO `user` VALUES ('31', '', 't1wd9', '', '9', '1');
INSERT INTO `user` VALUES ('33', 'TEST USER', 't56', '', '9', '1');
INSERT INTO `user` VALUES ('35', 'TEST USER', 't123', '', '9', '1');
INSERT INTO `user` VALUES ('44', 'TEST USER', 't863', '', '9', '1');
INSERT INTO `user` VALUES ('46', 'TEST USER', 't8633', '', '9', '1');
INSERT INTO `user` VALUES ('48', 'TEST USER', 't786', '', '9', '1');
INSERT INTO `user` VALUES ('52', 'TEST USER', 't08723', '', '9', '1');
