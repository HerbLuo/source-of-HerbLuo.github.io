package cn.cloudself.service.impl

import cn.cloudself.exception.http.RequestBadException
import cn.cloudself.exception.http.ServerException
import cn.cloudself.service.ISearchService
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.net.URL
import java.sql.Timestamp
import javax.persistence.EntityManager
import javax.persistence.PersistenceContext
import javax.persistence.Query

/**
 * @author HerbLuo
 * @version 1.0.3.r
 *
 * change logs:
 * 2017/11/20 HerbLuo 首次创建
 * 2017/12/10 HerbLuo 添加范围搜索和数组搜索 1.0.1
 * 2017/12/26 HerbLuo 添加timestamp类型的搜索 1.0.2
 * 2017/12/27 HerbLuo 修复文件路径错误 1.0.3
 */
@Service
@Transactional
open class SearchServiceImpl : ISearchService {

    private var entityManager: EntityManager? = null
    private val searchConfig = ConfigLoader.loadConfig()

    @PersistenceContext
    fun setEntityManager(entityManager: EntityManager) {
        this.entityManager = entityManager
    }

    @Throws(Exception::class)
    override fun <T> search(entityName: String,
                            properties: String,
                            searchText: String,
                            pageable: Pageable,
                            clazz: Class<T>): Iterable<T> {
        @Suppress("UNCHECKED_CAST")
        return search(entityName, properties, searchText, pageable) as Iterable<T>
    }

    @Throws(Exception::class)
    override fun search(entityName: String,
                        properties: String,
                        searchText: String,
                        pageable: Pageable): Iterable<*> {
        if (!searchConfig.haveEntity(entityName)
                || !searchConfig.haveProperty(entityName, properties)) {
            throw RequestBadException(Messages.ILLEGAL_REQUEST_PARAMS)
        }

        val type: String = searchConfig.findPropertyType(entityName, properties)
                ?: throw ServerException(Messages.TYPE_CAN_NOT_BE_NULL_CONFIG_ERROR)

        val (hql, params) = QueryCreator.create(type, entityName,
                properties, searchText)

        // 前两页延时0.5秒，后面的延时1秒
        Thread.sleep(if (pageable.pageNumber < 2) 500 else 1000)

        return entityManager!!
                .createQuery(hql)
                .also { query ->
                    params.forEach({
                        query.setParameter(it.key, it.value)
                    })
                }
                .autoPage(pageable)
    }

}

/* *********
 query creator
 ********* */
private data class HqlAndParams(
        val hql: String,
        val params: Params<Any>
)
private typealias Params<T> = Map<String, T>
private typealias SearchToParams<T> = (searchText: String) -> Params<T>
private object QueryCreator {
    fun create(type: String,
               entityName: String,
               properties: String,
               searchText: String): HqlAndParams {
        fun create(map: Map<String, Pair<String, SearchToParams<Any>>>): HqlAndParams {
            val prefix = "SELECT entity FROM $entityName entity WHERE entity.$properties "
            val (suffix, paramsGetter) = map[type]
                    ?: throw ServerException(Messages.UN_SUPPORT_COLUMN_TYPE_CONFIG_ERROR)
            return HqlAndParams(prefix + suffix, paramsGetter(searchText))
        }

        val searchTextPrefix =
                if (searchText.length > 2) searchText.substring(0, 2) else ""

        return when (searchTextPrefix) {
            "[," -> create(arrayMap)
            "[~" -> create(rangeMap)
            else -> create(normalMap)
        }
    }

    private val normalMap = mapOf<String, Pair<String, SearchToParams<Any>>>(
            "string" to "like :p1" and
                    { s -> mapOf("p1" to "%$s%") },
            "int" to "= :p1" and
                    { s -> mapOf("p1" to s.toInt()) },
            "boolean" to "= :p1" and
                    { s -> mapOf("p1" to s.toBoolean()) },
            "double" to "= :p1" and
                    { s -> mapOf("p1" to s.toDouble()) },
            "timestamp" to "= :p1" and
                    { s -> mapOf("p1" to Timestamp(s.toLong())) }
    )

    private val arrayMap = mapOf<String, Pair<String, SearchToParams<List<Any>>>>(
            "int" to "IN :p1" and
                    { s ->
                        mapOf("p1" to
                                s.mySplit(",").map { it.trim().toInt() })
                    },
            "double" to "IN :p1" and
                    { s ->
                        mapOf("p1" to
                                s.mySplit(",").map { it.trim().toDouble() })
                    },
            "timestamp" to "IN :p1" and
                    { s ->
                        mapOf("p1" to
                                s.mySplit(",").map { Timestamp(it.trim().toLong()) })
                    }
    )

    private val rangeMap = mapOf<String, Pair<String, SearchToParams<Any>>>(
            "int" to "BETWEEN :p1 AND :p2" and
                    { s ->
                        val arr = s.mySplit("~")
                        if (arr.size < 2) {
                            throw RequestBadException(Messages.ILLEGAL_REQUEST_PARAMS)
                        }
                        mapOf(
                                "p1" to arr[0].trim().toInt(),
                                "p2" to arr[1].trim().toInt()
                        )
                    },
            "double" to "BETWEEN :p1 AND :p2" and
                    { s ->
                        val arr = s.mySplit("~")
                        if (arr.size < 2) {
                            throw RequestBadException(Messages.ILLEGAL_REQUEST_PARAMS)
                        }
                        mapOf(
                                "p1" to arr[0].trim().toDouble(),
                                "p2" to arr[1].trim().toDouble()
                        )
                    },
            "timestamp" to "BETWEEN :p1 AND :p2" and
                    { s ->
                        val arr = s.mySplit("~")
                        if (arr.size < 2) {
                            throw RequestBadException(Messages.ILLEGAL_REQUEST_PARAMS)
                        }
                        mapOf(
                                "p1" to Timestamp(arr[0].trim().toLong()),
                                "p2" to Timestamp(arr[1].trim().toLong())
                        )
                    }
    )

    private fun String.mySplit(s: String) =
            this.substring(2, this.length - 1).split(s)

    private infix fun <A, B, C> Pair<A, B>.and(that: C): Pair<A, Pair<B, C>> =
            Pair(this.first, Pair(this.second, that))
}

/* *********
 magic strings
 ********* */

private object Messages {
    val ILLEGAL_REQUEST_PARAMS = "参数不合法"
    val UN_SUPPORT_COLUMN_TYPE_CONFIG_ERROR =
            "[CONFIG ERROR] un-support column type"
    val TYPE_CAN_NOT_BE_NULL_CONFIG_ERROR =
            "[CONFIG ERROR] type can not be null"
}

/* *********
 utils
 ********* */
/**
 * 自动分页
 * (只需提供 页数和每页大小，无需提供总页数)
 *
 * 原理为：查询时多查一个值，如查到，则证明存在下一页，将总页数设为当前页 +1
 */
private fun Query.autoPage(pageable: Pageable): Page<*> {
    val pageNumber = pageable.pageNumber
    val pageSize = pageable.pageSize

    val result = this
            .setFirstResult(pageNumber * pageSize)
            .setMaxResults(pageSize + 1)
            .resultList

    val resultSize = result.size
    val total: Int = pageSize * pageNumber + resultSize +
            if (resultSize > pageSize) 1 else 0

    return PageImpl(result, pageable, total.toLong())
}

/* *********
 config loader
 ********* */
private data class Config(
        var version: String? = null,
        var search: List<Search>? = null
) {
    data class Search(
            var entityName: String? = null,
            var properties: List<Column>? = null
    )

    data class Column(
            var name: String? = null,
            var type: String = "string"
    )
}

private fun findSearch(config: Config, tableName: String): Config.Search? =
        config.search?.find { it.entityName == tableName }

private fun findColumn(config: Config, tableName: String,
                       columnName: String): Config.Column? =
        findSearch(config, tableName)?.properties?.find { it.name == columnName }

private fun Config.haveEntity(tableName: String): Boolean =
        findSearch(this, tableName) != null

private fun Config.findPropertyType(tableName: String, columnName: String): String? =
        findColumn(this, tableName, columnName)?.type

private fun Config.haveProperty(tableName: String, columnName: String): Boolean =
        findColumn(this, tableName, columnName) != null

private object ConfigLoader {
    fun loadConfig(): Config =
            loadConfig(
                    Thread
                            .currentThread()
                            .contextClassLoader
                            .getResource("searchConfig.json")
            )

    fun loadConfig(url: URL): Config =
            ObjectMapper().readValue(url, Config::class.java)
}
