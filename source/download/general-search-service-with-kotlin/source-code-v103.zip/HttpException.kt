package cn.cloudself.exception.http

/**
 * @author HerbLuo
 * @version 1.0.0.d
 */
open class HttpException : Exception {

    var code: Int = 0

    constructor() : super() {}

    constructor(code: Int) : super() {
        this.code = code
    }

    constructor(message: String) : super(message) {}

    constructor(message: String, code: Int) : super(message) {
        this.code = code
    }

    constructor(message: String, cause: Throwable) : super(message, cause) {}

    constructor(message: String, cause: Throwable, code: Int) : super(message, cause) {
        this.code = code
    }

    constructor(cause: Throwable) : super(cause) {}
}

open class HttpWarm : HttpException {

    constructor() {}

    constructor(code: Int) : super(code) {}

    constructor(message: String) : super(message) {}

    constructor(message: String, code: Int) : super(message, code) {}

    constructor(message: String, cause: Throwable) : super(message, cause) {}

    constructor(message: String, cause: Throwable, code: Int) : super(message, cause, code) {}

    constructor(cause: Throwable) : super(cause) {}

}

open class HttpError : HttpException {
    constructor() {}

    constructor(code: Int) : super(code) {}

    constructor(message: String) : super(message) {}

    constructor(message: String, code: Int) : super(message, code) {}

    constructor(message: String, cause: Throwable) : super(message, cause) {}

    constructor(message: String, cause: Throwable, code: Int) : super(message, cause, code) {}

    constructor(cause: Throwable) : super(cause) {}
}
